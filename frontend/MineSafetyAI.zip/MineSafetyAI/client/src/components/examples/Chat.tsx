import Chat from '../../pages/Chat';

export default function ChatExample() {
  return <Chat />;
}
