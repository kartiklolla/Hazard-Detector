import Scraper from '../../pages/Scraper';

export default function ScraperExample() {
  return <Scraper />;
}
