import Landing from '../../pages/Landing';

export default function LandingExample() {
  return <Landing />;
}
