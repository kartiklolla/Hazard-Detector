import Analytics from '../../pages/Analytics';

export default function AnalyticsExample() {
  return <Analytics />;
}
