import Reports from '../../pages/Reports';

export default function ReportsExample() {
  return <Reports />;
}
