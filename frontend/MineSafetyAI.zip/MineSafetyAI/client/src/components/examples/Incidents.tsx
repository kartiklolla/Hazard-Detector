import Incidents from '../../pages/Incidents';

export default function IncidentsExample() {
  return <Incidents />;
}
